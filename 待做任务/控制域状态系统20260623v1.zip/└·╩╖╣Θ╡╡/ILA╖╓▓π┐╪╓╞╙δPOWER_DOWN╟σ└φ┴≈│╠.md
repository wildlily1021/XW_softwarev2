# ILA分层控制与 POWER_DOWN 清理流程

## 1. 适用范围

本流程适用于以下 RTL 收口场景：

- 现有工程只保留一个总 `ILA_EN`，无法单独控制子模块 ILA。
- 某模块内存在历史 `POWER_DOWN` 常量，但后续不再需要。
- 需要给模块树补统一的 `generate if (ILA_EN)` ILA 挂点。

当前已按本流程完成的示例模块：

- `import/rtl_source/ctrl_status_block/`

## 2. 目标结构

目标不是“把 ILA 打开”，而是先把 ILA 控制常量的层级关系收口清楚：

1. 从系统顶层开始定义父开关。
2. 父模块为每个直接子模块定义独立 ILA 常量。
3. 子模块只消费自己的 `ILA_EN`，并在需要时继续向下传递更细的子开关。
4. 每个模块末尾统一保留：

```systemverilog
generate
    if (ILA_EN) begin : gen_ila
        // Reserved for <module> ILA instances.
    end
endgenerate
```

这样即使当前还没有真实 ILA IP，也已经把后续插入位置固定下来。

## 3. 推荐命名

### 3.1 顶层常量命名

在系统顶层采用“块名 + 子层级”展开，例如：

```systemverilog
localparam logic ILA_EN_CTRL_STATUS_C               = 1'b0;
localparam logic ILA_EN_CTRL_STATUS_RS422_ADAPTER_C = 1'b0 & ILA_EN_CTRL_STATUS_C;
localparam logic ILA_EN_CTRL_STATUS_RS422_RX_LINK_C = 1'b0 & ILA_EN_CTRL_STATUS_RS422_ADAPTER_C;
localparam logic ILA_EN_CTRL_STATUS_RS422_FRAME_RX_C = 1'b0 & ILA_EN_CTRL_STATUS_RS422_RX_LINK_C;
```

原则：

- 顶层默认值统一从 `1'b0` 起步。
- 子常量默认写成 `1'b0 & 父常量`。
- 这样后续只改一处即可逐级放开。

### 3.2 模块参数命名

模块内部参数分两类：

- 本模块自身 ILA：`ILA_EN`
- 直接子模块 ILA：`ILA_<child_name>_EN`

例如：

```systemverilog
module xxx_parent #(
    parameter bit ILA_EN          = 1'b0,
    parameter bit ILA_CHILD_A_EN  = 1'b0,
    parameter bit ILA_CHILD_B_EN  = 1'b0
);
```

## 4. 实施步骤

### 步骤 1：先画出实际例化树

先确认真实层级，不要只看文件夹。

至少写清：

- 顶层模块是谁
- 哪些子模块真的被例化
- 哪些文件只是候选/公共模块，当前并未挂到顶层

只有真实例化树上的模块，才需要从顶层一路传递 ILA 常量。

### 步骤 2：顶层新增 ILA 常量

在系统顶层：

- 新增该 block 的总开关
- 新增该 block 内各级子模块开关
- 在 block 顶层实例参数中显式传入

### 步骤 3：父模块拆分“自身 ILA”和“子模块 ILA”

父模块不要把同一个 `ILA_EN` 同时发给所有子模块。

应改成：

- `ILA_EN` 只控制本模块自己的 `generate if`
- `ILA_CHILD_xxx_EN` 分别传给对应子模块

### 步骤 4：叶子模块补统一挂点

对每个叶子模块：

- 保留/新增 `parameter bit ILA_EN = 1'b0`
- 文件末尾统一加 `generate if (ILA_EN)`
- 如果当前没有真实 ILA，只留注释占位

### 步骤 5：删除 `POWER_DOWN`

如果确认 `POWER_DOWN` 只剩“常量门控 ready”用途，则：

1. 删除参数定义
2. 删除参数传递
3. 删除 `module_ready_o` 中的 `POWER_DOWN` 条件
4. 保留原有 reset、参数合法性等真实结构条件

注意：

- 只有在 `POWER_DOWN` 不再参与状态机、握手、FIFO 读写、CDC、复位流程时，才允许直接删除。

### 步骤 6：做两类验证

#### 6.1 结构检查

至少检查：

- `ctrl_status_block` 内是否仍残留 `POWER_DOWN`
- 每个模块是否都有 `ILA_EN`
- 每个模块是否都有 `if (ILA_EN) begin`

#### 6.2 语法检查

优先使用工程规定版本：

```text
D:\Xilinx\Vivado\2018.3\bin\xvlog.bat
```

避免裸用环境变量里的 Vivado 命令。

## 5. 本次 ctrl_status_block 落地结果

本次 `ctrl_status_block` 采用的分层如下：

- `top.sv`
  - `ILA_EN_CTRL_STATUS_C`
  - `ILA_EN_CTRL_STATUS_RS422_ADAPTER_C`
  - `ILA_EN_CTRL_STATUS_RS422_RX_PHY_C`
  - `ILA_EN_CTRL_STATUS_RS422_RX_LINK_C`
  - `ILA_EN_CTRL_STATUS_RS422_FRAME_RX_C`
  - `ILA_EN_CTRL_STATUS_RS422_RX_BAUD_C`
  - `ILA_EN_CTRL_STATUS_RS422_TX_LINK_C`
  - `ILA_EN_CTRL_STATUS_RS422_FRAME_TX_C`
  - `ILA_EN_CTRL_STATUS_RS422_TX_BAUD_C`
  - `ILA_EN_CTRL_STATUS_RS422_TX_PHY_C`
  - `ILA_EN_CTRL_STATUS_HOST_CTRL_C`

- `top_ctrl_status_block`
  - 拆分为 `RS422 adapter` 和 `host_ctrl_core` 两个直接子开关入口

- `ctrl_status_rs422_link_adapter`
  - 再继续拆成 `rx_phy/rx_link/frame_rx/rx_baud/tx_link/frame_tx/tx_baud/tx_phy`

## 6. 后续模块复用模板

后续处理其他 block 时，按下面顺序复制即可：

1. 先列出真实例化树。
2. 在 `top.sv` 增加该 block 的总 ILA 常量。
3. 为该 block 的直接子模块增加独立 ILA 常量。
4. 在 block 顶层参数列表中显式展开这些常量。
5. 每个被例化模块新增 `ILA_EN` 参数。
6. 每个模块末尾统一补 `generate if (ILA_EN)`。
7. 如果存在历史 `POWER_DOWN`，先确认仅剩 ready 门控用途，再删除。
8. 跑结构检查。
9. 跑 `xvlog` 语法检查。

## 7. 禁止事项

- 不要继续把同一个 `ILA_EN` 扇出给整棵子树。
- 不要在没看清真实例化树时，机械地给所有文件乱传参数。
- 不要删除 `POWER_DOWN` 后顺手改状态机或握手逻辑。
- 不要只改顶层，不给叶子模块补统一 `generate` 挂点。
