# rs422-stat 融合设计说明

## 目标

将 `rs422-stat` 分支中已经实现的 `RS422 + 控制与状态` 功能迁入当前 `master` 工作区，并以 `master` 当前顶层框架、目录结构、模块命名和接口风格为准完成重构融合。

## 总体原则

- `rs422-stat` 分支本身不删除、不改写历史、不回退。
- 不直接合并 `rs422-stat` 分支历史。
- 只迁移 `RS422/控制与状态` 功能代码和对应说明文档。
- 其余所有子系统结构、命名、目录、顶层框架以 `master` 当前版本为准。

## 代码来源边界

### 允许迁入的来源

- `import/rtl_source/HOST_CTRL_STATUS/...`
- `import/rtl_source/RS422/...`
- `工程部署/工程实现/主机控制与状态协议层/...`
- `工程部署/工程实现/00_总体说明/控制与状态接口说明.md`

### 不迁入的来源

- `import/rtl_source/TOP/...`
- `sim/rs422/...`
- `.standards/...`
- `工程部署/工具/...`
- 旧的 `GT / 通信 / 业务` 功能实现文件

## 目标落点

### RTL

所有控制与状态相关 RTL 统一落到：

- `import/rtl_source/ctrl_status_block/`

其中：

- 顶层模块保持为 `top_ctrl_status_block.sv`
- 包文件保持为 `ctrl_status_block_pkg.sv`
- 新增内部子模块文件，命名统一以 `ctrl_status_` 为前缀
- 目录按 `rs422_phy/`、`rs422_link/`、`frame_processing/` 三类收口

### 文档

所有现役说明文档统一落到：

- `工程部署/工程实现/控制与状态模块/`

分支中的 `主机控制与状态协议层/` 文档作为内容来源拆解吸收，不整目录原样迁入。

## 融合后的 RTL 结构

### 顶层保留

- `top_ctrl_status_block`

### 新增内部子模块

- `rs422_phy/`
  - `ctrl_status_rs422_rx_phy.sv`
  - `ctrl_status_rs422_tx_phy.sv`
  - `ctrl_status_rs422_baud_gen.sv`
- `rs422_link/`
  - `ctrl_status_rs422_link_adapter.sv`
  - `ctrl_status_rs422_rx_link.sv`
  - `ctrl_status_rs422_tx_link.sv`
  - `ctrl_status_rs422_frame_rx.sv`
  - `ctrl_status_rs422_frame_tx.sv`
- `frame_processing/`
  - `ctrl_status_cmd_param_splitter.sv`
  - `ctrl_status_cmd_action_mapper.sv`
  - `ctrl_status_tm_frame_builder.sv`
  - `ctrl_status_host_ctrl_core.sv`

## 接口融合原则

当前现役控制与状态接口以以下三类通道为准：

- `cmd_axis_t`
- `stat_axis_t`
- `tm_req_*`

本次融合后，各一级功能模块统一扩展为：

- `cmd_axi4_i`
- `cmd_axi4_ready_o`
- `tm_req_valid_i`
- `tm_req_group_id_i`
- `tm_req_ready_o`
- `stat_axi4_o`
- `stat_axi4_ready_i`

顶层 `top.sv` 需要新增按模块索引管理的：

- `tm_req_valid[MODULE_NUM-1:0]`
- `tm_req_group_id[MODULE_NUM-1:0]`
- `tm_req_ready[MODULE_NUM-1:0]`

## 协议与命名适配

### module_id

- `rs422-stat` 分支内部协议使用 `4bit module_id`
- `master` 当前公共框架使用 `8bit module_id`

融合后策略：

- 外部框架继续保留 `master` 的 `8bit module_id`
- 控制与状态私有协议层内部兼容 `4bit` 解码语义
- 在 `top_ctrl_status_block` 内部做 `4bit -> 8bit` 映射到 `master` 模块索引

### AXI 接口

- `rs422-stat` 分支大量采用展开的 `tdata/tkeep/tvalid/tlast`
- `master` 当前统一使用 `cmd_axis_t / stat_axis_t`

融合后策略：

- `top_ctrl_status_block` 对外继续保持 `struct` 风格
- 内部核心模块允许继续使用展开口
- 在 `top_ctrl_status_block` 内部完成 `struct <-> 标量` 适配

并且不再保留单独模块级软件复位分发接口。

## 功能职责

融合完成后，`top_ctrl_status_block` 负责：

- 接收 `RS422` 串行控制输入
- 完成帧恢复、帧校验和 `payload` 提取
- 解析控制头并按 `module_id` 分发 `cmd_axi4`
- 周期轮询各模块 `tm_req_*`
- 汇聚各模块 `stat_axi4`
- 通过 `RS422` 发送回主机

## 文档融合策略

保留现役入口：

- `控制与状态模块/README.md`

新增现役专题文档：

- `RS422链路与帧边界说明.md`
- `命令分发与模块ID映射.md`
- `遥测请求与状态回传机制.md`

## 风险点

### 1. 模块接口全面扩展

所有一级模块和 `top.sv` 都要补 `tm_req_*`，改动面较大，但结构简单。

### 2. module_id 位宽不一致

如果映射没有统一收口，容易出现控制分发目标错位。

### 3. 分支历史文档口径与主枝框架冲突

必须保证文档迁入时只保留现役口径，不把旧目录结构重新引入主枝。

### 4. 当前工作区已有未提交改动

融合时只能在当前工作区已有改动基础上继续前推，不能回滚其他无关变更。
