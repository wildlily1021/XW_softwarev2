# ctrl_status_block 无用变量与常量检查说明

## 1. 本轮范围

- 检查目录：`import/rtl_source/ctrl_status_block`
- 检查对象：
  - `localparam`
  - `parameter`
  - 模块内 `logic/wire/reg/bit/int/integer/byte` 声明
- 不包含：
  - 端口是否被上层外部系统使用的语义判断
  - package 中通过宏、脚本、字符串反射等间接使用的场景
  - Vivado 约束、ILA 工程外部脚本对名字的潜在引用

## 2. 检查方法

本轮采用两层方法：

1. 对 `ctrl_status_block` 目录下 `.sv/.svh/.v` 文件做静态扫描，抽取变量/常量声明，并统计同目录内标识符引用次数。
2. 对低引用项做人工复核，区分：
   - 已确认无用
   - 当前实现未消费，但出于兼容/占位保留
   - 命名即表示“未用”的接线占位

说明：

- “引用次数 = 1”通常表示只有声明本身，没有任何后续使用。
- “引用次数 = 2”在本次口径下通常表示：
  - 一次是声明
  - 一次是被连接到子模块未消费端口，或仅被上层透传
- 这类项不能一律视为“应删除”，需要结合设计意图判断。

## 3. 已确认无用项

### 3.1 `MODULE_ID_CTRL_STATUS_C`

- 文件：[ctrl_status_block_pkg.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/ctrl_status_block_pkg.sv:97)
- 类型：`localparam`
- 结论：当前目录内未被任何逻辑引用，属于已确认无用常量候选。

说明：

- 同组常量 `MODULE_ID_CLK_MGMT_C` 到 `MODULE_ID_COMM_RX_C` 形成一组模块 ID 常量。
- 其中仅 `MODULE_ID_CTRL_STATUS_C` 在当前扫描范围内没有被使用。
- 若后续没有外部脚本或文档生成工具依赖该名字，可以考虑删除。

### 3.2 `SIMULATION`

- 文件：[top_ctrl_status_block.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/top_ctrl_status_block.sv:7)
- 类型：`parameter`
- 结论：当前模块内部未消费，属于已确认无用参数候选。

说明：

- 该参数只在参数列表中声明，没有参与任何 generate、if、assign、实例化参数传递或行为分支。
- 如果控制与状态模块后续不计划做仿真/综合分支，可以考虑删除。

## 4. 当前未消费但建议保留项

这类项从“纯 RTL 本地引用”看是低引用，但不建议直接按“无用”删除。

### 4.1 `ILA_RX_LINK_EN`

- 文件：[ctrl_status_rs422_link_adapter.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/rs422_link/ctrl_status_rs422_link_adapter.sv:33)
- 类型：`parameter`
- 结论：当前实现已不再例化 `rx_link`，因此此参数在 adapter 内部未消费；但上层仍在透传，属于兼容保留项。

关联上层：

- [top_ctrl_status_block.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/top_ctrl_status_block.sv:123)

说明：

- 该参数在“删除 `rx_link` 层级、adapter 直连 frame”后已经失去实际功能。
- 但如果现在删除，需要同步修改 `top_ctrl_status_block.sv` 及更上层参数链。
- 建议先在文档中标记为“兼容保留，待统一清理”。

### 4.2 `ILA_TX_LINK_EN`

- 文件：[ctrl_status_rs422_link_adapter.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/rs422_link/ctrl_status_rs422_link_adapter.sv:36)
- 类型：`parameter`
- 结论：与 `ILA_RX_LINK_EN` 同类，当前内部未消费，但上层仍透传，建议先保留。

关联上层：

- [top_ctrl_status_block.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/top_ctrl_status_block.sv:126)

## 5. 命名即表示“未用占位”的信号

以下项从设计意图上看，不属于“误留无用逻辑”，而是明确的子模块未用输出接线占位。

### 5.1 `rx_timer_active_unused_w`

- 文件：[ctrl_status_rs422_frame_rx.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/rs422_link/ctrl_status_rs422_frame_rx.sv:98)
- 类型：`logic`
- 结论：命名已明确为 unused，占位接收 `ctrl_status_rs422_baud_gen.timer_active_o`，不是误留变量。

### 5.2 `tx_half_bit_tick_unused_w`

- 文件：[ctrl_status_rs422_frame_tx.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/rs422_link/ctrl_status_rs422_frame_tx.sv:85)
- 类型：`logic`
- 结论：命名已明确为 unused，占位接收 `half_bit_tick_o`，不是误留变量。

### 5.3 `tx_timer_active_unused_w`

- 文件：[ctrl_status_rs422_frame_tx.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/rs422_link/ctrl_status_rs422_frame_tx.sv:86)
- 类型：`logic`
- 结论：命名已明确为 unused，占位接收 `timer_active_o`，不是误留变量。

说明：

- 这类信号如果要清理，建议直接把实例端口改接空连接 `()`。
- 但是否允许对该类输出统一使用空连接，需要先确认团队在可观测性和风格上的约束。

## 6. 本轮未判定为无用的低引用项

下列项虽然引用次数低，但人工复核后认为仍有明确用途，不应纳入“无用变量/常量”：

- `HOST_CTRL_RESERVE_W`
  - [ctrl_status_block_pkg.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/ctrl_status_block_pkg.sv:55)
  - 用于结构体字段宽度定义。
- `HOST_CTRL_VERSION_C`
  - [ctrl_status_block_pkg.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/ctrl_status_block_pkg.sv:70)
  - 被遥测帧头版本字段使用。
- `ACTION_TABLE_PACKED` / `MAP_TABLE_PACKED`
  - [ctrl_status_cmd_action_mapper.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/frame_processing/ctrl_status_cmd_action_mapper.sv:38)
  - 通过函数切片访问。
- `GROUP_TABLE_PACKED` / `PARAM_TABLE_PACKED`
  - [ctrl_status_cmd_param_splitter.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/frame_processing/ctrl_status_cmd_param_splitter.sv:39)
  - 通过函数切片访问。
- `MAX_PAYLOAD_WORDS_U8`
  - [ctrl_status_cmd_param_splitter.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/frame_processing/ctrl_status_cmd_param_splitter.sv:87)
  - 用于 payload 计数上限判断。
- `TM_PERIOD_CYCLES_U32` / `TM_FRAME_TIMEOUT_CYCLES_U32`
  - [ctrl_status_host_ctrl_core.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/frame_processing/ctrl_status_host_ctrl_core.sv:418)
  - 用于周期计数和超时判断。
- `ILA_RS422_*` 上层参数
  - [top_ctrl_status_block.sv](/D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/ctrl_status_block/top_ctrl_status_block.sv:9)
  - 大部分仍在参数透传链路上使用。

## 7. 建议的后续处理顺序

### 7.1 可直接清理候选

优先级较高，可单独评审：

1. `MODULE_ID_CTRL_STATUS_C`
2. `SIMULATION`

### 7.2 需要成组清理的兼容项

建议与接口收口任务一起做，不要单点删除：

1. `ILA_RX_LINK_EN`
2. `ILA_TX_LINK_EN`
3. `top_ctrl_status_block.sv` 中对应的 `ILA_RS422_RX_LINK_EN`
4. `top_ctrl_status_block.sv` 中对应的 `ILA_RS422_TX_LINK_EN`

### 7.3 风格类清理项

如团队允许空连接 `()`，可统一处理：

1. `rx_timer_active_unused_w`
2. `tx_half_bit_tick_unused_w`
3. `tx_timer_active_unused_w`

## 8. 当前结论

按本轮静态扫描与人工复核，`import/rtl_source/ctrl_status_block` 下当前最明确的无用项是：

1. `MODULE_ID_CTRL_STATUS_C`
2. `SIMULATION`

此外还有一组“当前已无实际功能，但为兼容上层参数链保留”的项：

1. `ILA_RX_LINK_EN`
2. `ILA_TX_LINK_EN`

而 `*_unused_w` 这类信号属于显式占位命名，不建议在文档中直接归类为“误留无用变量”。
