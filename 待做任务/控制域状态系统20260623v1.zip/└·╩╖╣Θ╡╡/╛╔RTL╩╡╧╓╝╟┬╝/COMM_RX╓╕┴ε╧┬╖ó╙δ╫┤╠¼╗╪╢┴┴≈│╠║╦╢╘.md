# COMM_RX指令下发与状态回读流程核对

## 1. 目的与范围

本文档按当前 `master` 现役 RTL，对 `COMM_RX` 方向的：

1. 一条指令下发
2. 一条配置回读
3. 一条 runtime 上传

做逐模块链路说明，并检查这些数据帧在各模块中的流程是否正确。

本文档只覆盖当前工程里的现役实现：

- `import/rtl_source/ctrl_status_block/`
- `import/rtl_source/comm_rx_block/`
- `import/rtl_source/top/top.sv`

若旧应用层表格、旧 `object_id` 口径、旧 `module_id` 定义与本文冲突，以当前 RTL 为准。

---

## 2. 现役链路总览

### 2.1 外层 RS422 固定帧

当前 `ctrl_status_rs422_frame_rx/tx` 使用固定帧壳：

```text
[4B header = 0x1ACFFC1D]
[4B payload_length_bytes]
[N*4B payload]
[4B checksum]
```

补充说明：

- `payload_length_bytes` 必须是 `4` 的整数倍。
- `checksum` 为 `header + payload_length_bytes + 所有 payload word` 的 `32-bit` 累加和。
- 每个 `32-bit word` 在串口字节流中按 `[31:24] -> [23:16] -> [15:8] -> [7:0]` 顺序发送。

### 2.2 应用层 payload 头

当前 payload 第 `0` 个字固定为应用层头：

```text
[31:28] version
[27:24] msg_type
[23:20] module_id
[19:12] group_id
[11:4]  param_count
[3:0]   reserve
```

当前现役共享定义：

- `version = 4'h1`
- `msg_type = 4'h1` 表示遥控
- `msg_type = 4'h2` 表示遥测
- `module_id = 4'h8` 表示 `COMM_RX`
- `TM_GROUP_RUNTIME_C = 8'h80`
- `TM_GROUP_CFG_C = 8'h81`

### 2.3 现役模块链路

接收方向：

```text
rs422_rx_i
-> ctrl_status_rs422_rx_phy
-> ctrl_status_rs422_rx_link
-> ctrl_status_host_ctrl_core
-> top_comm_rx_block / comm_rx_cmd_agent
-> ctrl_status_cmd_param_splitter
-> ctrl_status_cmd_action_mapper
-> comm_rx_param_sink
-> comm_rx_impl
```

发送方向：

```text
comm_rx_impl
-> comm_rx_tm_agent
-> ctrl_status_tm_frame_builder
-> ctrl_status_host_ctrl_core
-> ctrl_status_rs422_tx_link
-> ctrl_status_rs422_tx_phy
-> rs422_tx_o
```

### 2.4 当前时钟域结论

当前现役顶层 [top.sv](D:/vivado_project/CZW/CZW_V7_runner_201803/repo_main/import/rtl_source/top/top.sv) 中：

- `top_ctrl_status_block` 工作在 `clk_sys_200m`
- `top_comm_rx_block.clk_local_200m_i` 也直接接到 `clk_sys_200m`

因此：

- `ctrl_status_host_ctrl_core -> comm_rx_cmd_agent`
- `ctrl_status_host_ctrl_core -> comm_rx_tm_agent`

这两段当前是同一 `200 MHz` 时钟域，不是实际 CDC 链路。

---

## 3. 三条实际示例

## 3.1 示例 A：一条指令下发

选择当前 RTL 真正支持的一条 `COMM_RX VALUE` 固定参数组：

- `module_id = 4'h8`
- `group_id = 8'h11 = COMM_RX_CMD_GROUP_VALUE_C`
- `param_count = 3`

这条命令一次性下发 3 个参数：

1. `frame_sync_corr_peak_th = 0x55`
2. `frame_lock_threshold = 0x0123`
3. `frame_unlock_threshold = 0x0045`

应用层 payload 4 个字如下：

```text
W0 = 0x11811030   // version=1, msg_type=1, module_id=8, group_id=0x11, param_count=3
W1 = 0x00000055   // sync_corr_peak_th
W2 = 0x00000123   // frame_lock_threshold
W3 = 0x00000045   // frame_unlock_threshold
```

对应外层 RS422 固定帧：

```text
FRAME_HEADER         = 0x1ACFFC1D
PAYLOAD_LENGTH_BYTES = 0x00000010
PAYLOAD              = 0x11811030 / 0x00000055 / 0x00000123 / 0x00000045
CHECKSUM             = 0x2C510E1A
```

---

## 3.2 示例 B：一条配置回读

假设示例 A 已经成功执行，且其它 `COMM_RX cfg` 字段仍保持默认值。

当前 `COMM_RX cfg` 组为：

- `group_id = 8'h81`
- `param_count = 10`

按 `comm_rx_ctrl_pkg::cfg_word()` 的当前顺序，payload 为：

```text
W0  = 0x128810A0   // version=1, msg_type=2, module_id=8, group_id=0x81, param_count=10
W1  = 0x00000000   // rate_sel            default 0
W2  = 0x00000000   // decode_sel          default 0
W3  = 0x00000000   // descramble_enable   default 0
W4  = 0x00000000   // carrier_filter_enable default 0
W5  = 0x00000000   // timing_loop_bw_sel  default 0
W6  = 0x00000000   // timing_filter_enable default 0
W7  = 0x00000055   // frame_sync_corr_peak_th = 0x55
W8  = 0x00000123   // frame_lock_threshold    = 0x0123
W9  = 0x00000045   // frame_unlock_threshold  = 0x0045
W10 = 0x00000000   // auto_reset_enable default 0
```

对应外层 RS422 固定帧：

```text
FRAME_HEADER         = 0x1ACFFC1D
PAYLOAD_LENGTH_BYTES = 0x0000002C
PAYLOAD              = 11 words
CHECKSUM             = 0x2D580EA6
```

---

## 3.3 示例 C：一条 runtime 上传

选择一条便于核对的 runtime 示例快照：

- `signal_power = 16'h0123`
- `carrier_freq_offset = 32'hFFFF_FFC0`   // -64
- `carrier_lock_state = 1`
- `symbol_lock_state = 1`
- `frame_lock_state = 1`
- `frame_count_sec = 100`
- `error_frame_count_sec = 5`
- `air_frame_count_sec = 16`
- `biz_frame_count_sec = 32`
- `total_bit_count_sec = 8192`
- `pre_dec_err_bits_sec = 3`
- `post_dec_err_bits_sec = 1`
- `ranging_reset_status = 0`
- `manual_reset_status = 0`

当前 `COMM_RX runtime` 组为：

- `group_id = 8'h80`
- `param_count = 14`

payload 为：

```text
W0  = 0x128800E0   // version=1, msg_type=2, module_id=8, group_id=0x80, param_count=14
W1  = 0x00000123
W2  = 0xFFFFFFC0
W3  = 0x00000001
W4  = 0x00000001
W5  = 0x00000001
W6  = 0x00000064
W7  = 0x00000005
W8  = 0x00000010
W9  = 0x00000020
W10 = 0x00002000
W11 = 0x00000003
W12 = 0x00000001
W13 = 0x00000000
W14 = 0x00000000
```

对应外层 RS422 固定帧：

```text
FRAME_HEADER         = 0x1ACFFC1D
PAYLOAD_LENGTH_BYTES = 0x0000003C
PAYLOAD              = 15 words
CHECKSUM             = 0x2D581EBC
```

---

## 4. 示例 A：指令下发逐模块流程

## 4.1 模块级职责表

| 模块 | 输入 | 输出 | 作用 |
| --- | --- | --- | --- |
| `ctrl_status_rs422_rx_phy` | `rs422_rx_i` 串口逻辑线 | `rx_line_o` | 只处理串口线级边界，不解释帧内容。 |
| `ctrl_status_rs422_frame_rx` | 串口位流 | payload word 流 | 校验 `0x1ACFFC1D`、长度字和 checksum，合法后按 `32-bit word` 输出 payload。 |
| `ctrl_status_rs422_rx_link` | `frame_payload_*` | `host_cmd_axi4` | 直接把合法 payload 转成 `cmd_axis_t`。 |
| `ctrl_status_host_ctrl_core` | `host_cmd_axi4` | `comm_rx_cmd_axi4_o` | 只解 `module_id=8`，把整条 payload 原封不动路由给 `COMM_RX`。 |
| `ctrl_status_cmd_param_splitter` | `COMM_RX` 整条命令 payload | 应用层参数拍流 | 先收完整组，再按 `group_id=0x11` 和 `param_count=3` 回放成 3 个参数拍。 |
| `ctrl_status_cmd_action_mapper` | 应用层参数拍流 | 实现层参数拍流 | 按 `ACTION_TABLE_C` 把 3 个参数变成 `CFG_WRITE`。 |
| `comm_rx_param_sink` | 实现层参数拍流 | `comm_rx_cfg_t` | 依次写入 3 个真实配置字段。 |
| `comm_rx_impl` | `cmd_params_i.cfg` | 实际算法端口 | 读取更新后的配置，并把字段接到 `transport_rece_data`。 |

## 4.2 各模块看到的数据应该是什么

### 4.2.1 `ctrl_status_rs422_rx_link` 输出给 `host_ctrl_core`

`host_cmd_axi4` 应为 4 拍：

```text
beat0: tdata=0x11811030 tkeep=0xF tlast=0
beat1: tdata=0x00000055 tkeep=0xF tlast=0
beat2: tdata=0x00000123 tkeep=0xF tlast=0
beat3: tdata=0x00000045 tkeep=0xF tlast=1
```

### 4.2.2 `ctrl_status_host_ctrl_core` 输出给 `COMM_RX`

`comm_rx_cmd_axi4_o` 应与上面完全相同，只是目标端口变成 `COMM_RX`：

```text
beat0: 0x11811030
beat1: 0x00000055
beat2: 0x00000123
beat3: 0x00000045 (tlast=1)
```

### 4.2.3 `ctrl_status_cmd_param_splitter` 输出的应用层参数拍流

当前 `group_id=0x11` 固定对应 3 个参数：

1. `COMM_RX_PARAM_SYNC_CORR_PEAK_TH_C`
2. `COMM_RX_PARAM_LOCK_TH_C`
3. `COMM_RX_PARAM_UNLOCK_TH_C`

因此输出应为：

```text
beat0: data=0x00000055 meta(group=0x11,param_id=7,param_kind=VALUE,word_idx=0,word_last=1) tlast=0
beat1: data=0x00000123 meta(group=0x11,param_id=8,param_kind=VALUE,word_idx=0,word_last=1) tlast=0
beat2: data=0x00000045 meta(group=0x11,param_id=9,param_kind=VALUE,word_idx=0,word_last=1) tlast=1
```

### 4.2.4 `ctrl_status_cmd_action_mapper` 输出的实现层参数拍流

这 3 个参数在 `ACTION_TABLE_C` 中都映射为 `ACTION_KIND_CFG_WRITE_C`，并且数据不变：

```text
beat0: data=0x00000055 meta(impl_param_id=7, action=CFG_WRITE, impl_word_idx=0, impl_word_last=1)
beat1: data=0x00000123 meta(impl_param_id=8, action=CFG_WRITE, impl_word_idx=0, impl_word_last=1)
beat2: data=0x00000045 meta(impl_param_id=9, action=CFG_WRITE, impl_word_idx=0, impl_word_last=1) tlast=1
```

### 4.2.5 `comm_rx_param_sink` 落地结果

这 3 拍结束后，本地配置应变成：

```text
cfg.frame_sync_corr_peak_th = 7'h55
cfg.frame_lock_threshold    = 16'h0123
cfg.frame_unlock_threshold  = 16'h0045
```

### 4.2.6 `comm_rx_impl` 真实消费点

`comm_rx_impl` 中对应的真实下游接线为：

```text
frmSyncCapTh_i = cmd_params_i.cfg.frame_sync_corr_peak_th
enterLockTh_i  = cmd_params_i.cfg.frame_lock_threshold[7:0]
lostLockTh_i   = cmd_params_i.cfg.frame_unlock_threshold[7:0]
```

这里已经暴露出 1 个实现级问题，见第 7 章。

---

## 5. 示例 B：配置回读逐模块流程

## 5.1 请求链路

配置回读不是主机显式下发一条“读命令”，而是 `ctrl_status_host_ctrl_core` 在轮询状态机中自动发起：

```text
tm_state = TM_ST_ISSUE_REQ_C
tm_slot  = TM_SLOT_COMM_RX_CFG_C
comm_rx_tm_req_valid_o    = 1
comm_rx_tm_req_group_id_o = 8'h81
```

`comm_rx_tm_agent` 在空闲且识别到 `group_id=8'h81` 时给出：

```text
tm_req_ready_o = 1
```

握手成功后开始本次配置回读。

## 5.2 模块级职责表

| 模块 | 输入 | 输出 | 作用 |
| --- | --- | --- | --- |
| `ctrl_status_host_ctrl_core` | `tm_req_ready_i` / `stat_axi4_i` | `tm_req_valid_o` / `tm_req_group_id_o` | 轮询到 `COMM_RX cfg` 槽位后发请求，并转发后续状态流。 |
| `comm_rx_tm_agent` | `tm_req_valid_i=1, group_id=0x81` | `frame_req_*` + `frame_data_*` | 锁存 `cfg` 快照，逐字调用 `cfg_word()`。 |
| `ctrl_status_tm_frame_builder` | `frame_group_id=0x81, frame_param_count=10` + 10 拍数据 | 标准 payload AXIS | 先发应用层头，再发 10 拍配置数据。 |
| `ctrl_status_host_ctrl_core` | `COMM_RX stat_axi4_i` | `host_stat_axi4_o` | 在 `WAIT_FIRST/FWD_FRAME` 状态原样转发。 |
| `ctrl_status_rs422_tx_link` | `host_stat_axi4` | 外层 RS422 帧 | 收满整帧 payload 后统一封装固定帧。 |

## 5.3 各模块看到的数据应该是什么

### 5.3.1 `comm_rx_tm_agent`

收到 `group_id=0x81` 请求后，应锁存：

```text
cfg_snapshot_r.rate_sel                = 0
cfg_snapshot_r.decode_sel              = 0
cfg_snapshot_r.descramble_enable       = 0
cfg_snapshot_r.carrier_filter_enable   = 0
cfg_snapshot_r.timing_loop_bw_sel      = 0
cfg_snapshot_r.timing_filter_enable    = 0
cfg_snapshot_r.frame_sync_corr_peak_th = 0x55
cfg_snapshot_r.frame_lock_threshold    = 0x0123
cfg_snapshot_r.frame_unlock_threshold  = 0x0045
cfg_snapshot_r.auto_reset_enable       = 0
```

### 5.3.2 `ctrl_status_tm_frame_builder`

发给 `host_ctrl_core` 的 `stat_axi4` 应为 11 拍：

```text
beat0 : 0x128810A0
beat1 : 0x00000000
beat2 : 0x00000000
beat3 : 0x00000000
beat4 : 0x00000000
beat5 : 0x00000000
beat6 : 0x00000000
beat7 : 0x00000055
beat8 : 0x00000123
beat9 : 0x00000045
beat10: 0x00000000 (tlast=1)
```

### 5.3.3 `ctrl_status_rs422_tx_link`

`tx_link` 收到上面 11 拍 payload 后，不会边收边发，而是：

1. 先缓存整条 payload
2. 算出 `payload_length_bytes = 0x2C`
3. 算出 `checksum = 0x2D580EA6`
4. 再以外层固定帧格式串行发出

---

## 6. 示例 C：runtime 上传逐模块流程

## 6.1 请求链路

runtime 上传同样由 `ctrl_status_host_ctrl_core` 自动轮询发起：

```text
tm_state = TM_ST_ISSUE_REQ_C
tm_slot  = TM_SLOT_COMM_RX_RUNTIME_C
comm_rx_tm_req_valid_o    = 1
comm_rx_tm_req_group_id_o = 8'h80
```

`comm_rx_tm_agent` 识别 `group_id=0x80` 后接收请求。

## 6.2 模块级职责表

| 模块 | 输入 | 输出 | 作用 |
| --- | --- | --- | --- |
| `comm_rx_impl` | 算法核原始状态 | `tm_params_o.stat` | 组织 runtime 快照源。 |
| `comm_rx_tm_agent` | `tm_params_i.stat` | 14 拍 runtime 数据 | 锁存状态快照，按 `runtime_word()` 固定顺序出字。 |
| `ctrl_status_tm_frame_builder` | `group_id=0x80, param_count=14` | 15 拍 payload | 加上头字后送到上层。 |
| `ctrl_status_host_ctrl_core` | `COMM_RX stat_axi4_i` | `host_stat_axi4_o` | 原样转发。 |
| `ctrl_status_rs422_tx_link` | `host_stat_axi4` | 外层 RS422 帧 | 封装并发送。 |

## 6.3 各模块看到的数据应该是什么

### 6.3.1 `comm_rx_impl`

`runtime_stat_o` 应按如下方式组织：

```text
signal_power          -> W1
carrier_freq_offset   -> W2
carrier_lock_state    -> W3
symbol_lock_state     -> W4
frame_lock_state      -> W5
frame_count_sec       -> W6
error_frame_count_sec -> W7
air_frame_count_sec   -> W8
biz_frame_count_sec   -> W9
total_bit_count_sec   -> W10
pre_dec_err_bits_sec  -> W11
post_dec_err_bits_sec -> W12
ranging_reset_status  -> W13
manual_reset_status   -> W14
```

### 6.3.2 `comm_rx_tm_agent`

发给 `ctrl_status_tm_frame_builder` 的 14 拍数据应为：

```text
W1  = 0x00000123
W2  = 0xFFFFFFC0
W3  = 0x00000001
W4  = 0x00000001
W5  = 0x00000001
W6  = 0x00000064
W7  = 0x00000005
W8  = 0x00000010
W9  = 0x00000020
W10 = 0x00002000
W11 = 0x00000003
W12 = 0x00000001
W13 = 0x00000000
W14 = 0x00000000
```

### 6.3.3 `ctrl_status_tm_frame_builder`

输出给上层的完整 payload 应为 15 拍：

```text
beat0 : 0x128800E0
beat1 : 0x00000123
beat2 : 0xFFFFFFC0
beat3 : 0x00000001
beat4 : 0x00000001
beat5 : 0x00000001
beat6 : 0x00000064
beat7 : 0x00000005
beat8 : 0x00000010
beat9 : 0x00000020
beat10: 0x00002000
beat11: 0x00000003
beat12: 0x00000001
beat13: 0x00000000
beat14: 0x00000000 (tlast=1)
```

---

## 7. 流程正确性核对

## 7.1 能确认正确的部分

当前 RTL 在下面这些点上是自洽的：

1. `RS422` 外层固定帧收发格式前后一致，接收和发送都按 `header + length + payload + checksum` 处理。
2. `ctrl_status_host_ctrl_core` 对命令路径只做 `module_id` 路由，不破坏 payload 内容，这与当前“模块内部自行解析 group/param”的设计一致。
3. `COMM_RX` 模块内部的三段式命令链是闭合的：
   - `splitter` 负责组校验与参数回放
   - `action_mapper` 负责动作归一化
   - `param_sink` 负责真实字段落地
4. `cfg` 和 `runtime` 遥测都经过 `tm_agent -> tm_frame_builder -> host_ctrl_core -> tx_link` 这一条统一返回路径，路径结构清晰。

## 7.2 已确认的问题和偏差

### 问题 1：旧应用层遥控文档曾与现役 RTL 不一致

此前仓库里仍保留过一组按旧协议口径组织的应用层遥控文档。它们使用的外部协议模型与当前现役 RTL 不一致，因此已经删除，不再保留为参考入口。

当前现役 RTL 实际要求的是：

- `COMM_RX module_id = 4'h8`
- 组式 `group_id + param_count`
- 固定组参数数量，不能按旧协议模型把参数拆成“单参数一条命令帧”

结论：

- 当前仿真激励和后续维护不得再参考已删除的旧应用层遥控文档。

### 问题 2：`ctrl_status -> comm_rx` 控制/遥测代理链路当前不是 CDC

规划文档把 `top_ctrl_status_block <-> top_comm_rx_block` 记成 CDC 边界，但当前现役顶层实际接线是：

```text
top_ctrl_status_block.clk_sys_200m_i -> clk_sys_200m
top_comm_rx_block.clk_local_200m_i   -> clk_sys_200m
```

结论：

- `cmd_axi4`
- `tm_req_*`
- `stat_axi4`

这几条控制与状态链当前都跑在同一个 `clk_sys_200m` 域里。

这不一定是功能错误，但说明：

- 当前仿真不应该把这段路径当作 CDC 场景验证。
- 规划文档需要和现役 RTL 重新对齐。

### 问题 3：`frame_lock_threshold` / `frame_unlock_threshold` 回读是 16 bit，但实现层只消费低 8 bit

协议层和 `cfg` 回读层都把这两个字段当作 `16-bit`：

```text
cfg.frame_lock_threshold
cfg.frame_unlock_threshold
```

但 `comm_rx_impl` 实际下传给 `transport_rece_data` 时使用的是：

```text
enterLockTh_i = cmd_params_i.cfg.frame_lock_threshold[7:0]
lostLockTh_i  = cmd_params_i.cfg.frame_unlock_threshold[7:0]
```

结论：

- 若主机下发 `0x0123`，配置回读会回 `0x0123`
- 但算法核真实只收到 `0x23`

因此当前“配置回读值”和“实现层真实生效值”在这两个字段上不一致。

### 问题 4：runtime 中两个 reset 状态位当前只是单拍脉冲镜像，无法作为稳定状态回读

当前 `comm_rx_impl` 中：

```text
runtime_stat_o.ranging_reset_status = cmd_params_i.ranging_reset_pulse
runtime_stat_o.manual_reset_status  = cmd_params_i.manual_reset_pulse
```

而这两个信号在 `comm_rx_param_sink` 中都是单拍脉冲。

结论：

- 它们不是“忙状态”
- 也不是“接受后保持的状态位”
- 仅是命令脉冲本身的一拍镜像

由于 `ctrl_status_host_ctrl_core` 的默认轮询周期是 `0.5 s`，主机几乎不可能通过周期遥测稳定观测到这两个单拍脉冲。

这与“通过周期遥测观测命令执行结果”的设计目标不一致。

### 问题 5：runtime 快照存在潜在 CDC 风险

下面这条判断来自代码连线推断：

- `comm_rx_tm_agent` 在 `clk_local_200m_i` 上锁存 `tm_params_i.stat`
- `tm_params_i.stat` 来自 `comm_rx_impl.runtime_stat_o`
- `runtime_stat_o` 的大部分源信号来自 `transport_rece_data`
- `transport_rece_data` 明确使用 `clk_adc_156m_i`、`clk_adc_200m_i`

但当前 `comm_rx_impl` 没有看到对这些 runtime 信号做显式同步或跨域快照寄存。

结论：

- `cfg` 回读链路当前是同域、相对干净的
- `runtime` 回读链路虽然功能上能出帧，但状态值的采样一致性当前没有结构级 CDC 证据

这一点在后续分层仿真时需要重点验证。

---

## 8. 当前收敛结论

围绕本轮要求的 `1-3`，当前可以先得出以下结论：

1. `COMM_RX` 的现役控制与状态链路已经能明确分成：
   - `RS422 固定帧层`
   - `host_ctrl_core 模块路由层`
   - `COMM_RX 三段式命令解析层`
   - `COMM_RX tm_agent/tm_frame_builder 遥测组帧层`
2. 以当前 RTL 为准，`COMM_RX` 已不是旧文档里的“单参数 object_id 协议”，而是“固定 group_id + 固定 param_count”的组式协议。
3. 指令下发链路在结构上是闭合的；配置回读链路也基本闭合。
4. runtime 上传链路在结构上能走通，但当前至少还存在：
   - runtime 源信号 CDC 证据不足
   - pulse 状态位不可观测
5. 若后续进入仿真，第一个优先仿真的不是顶层全链路，而应先做：
   - `ctrl_status_rs422_frame_rx/tx`
   - `ctrl_status_cmd_param_splitter`
   - `ctrl_status_cmd_action_mapper`
   - `comm_rx_tm_agent + ctrl_status_tm_frame_builder`
   - 最后再拼 `top_ctrl_status_block <-> top_comm_rx_block`

---

## 9. 本轮实际仿真执行结果

本轮已按“先底层、后半链路、暂不死磕持续不过用例”的原则执行到以下状态。

### 9.1 已通过的仿真

| 层级 | 仿真文件 | 结论 |
| --- | --- | --- |
| `COMM_RX` 本地落地 | `sim/comm_rx_block/ctrl_tm/tb_comm_rx_param_sink.sv` | 通过。验证默认值、配置写入、3 类 pulse 单拍输出。 |
| `COMM_RX` 本地命令链 | `sim/comm_rx_block/ctrl_tm/tb_comm_rx_cmd_agent.sv` | 通过。验证 `MAP` 固定 7 参数组、`VALUE` 固定 3 参数组、3 类 header-only pulse 组。 |
| `COMM_RX` 本地遥测链 | `sim/comm_rx_block/ctrl_tm/tb_comm_rx_tm_agent.sv` | 通过。验证 `cfg` 组 11 拍 payload 和 `runtime` 组 15 拍 payload。 |
| `RS422 frame_rx` 细粒度 | `sim/ctrl_status_block/rs422/tb_ctrl_status_rs422_frame_rx.sv` | 通过。验证外层固定帧接收、checksum 通过后能正确恢复 4 个 payload word。 |
| `RS422 frame_tx` 细粒度 | `sim/ctrl_status_block/rs422/tb_ctrl_status_rs422_frame_tx.sv` | 通过。验证 `frame_tx -> tx_phy -> rx_phy -> rx_link` roundtrip，4 个 payload word 可完整恢复。 |
| `RS422` 完整全回环 | `sim/ctrl_status_block/rs422/tb_ctrl_status_rs422_frame_loopback.sv` | 通过。验证命令 payload 4 words 与遥测 payload 15 words 都能经完整收发链往返恢复。 |
| 接收半链路集成 | `sim/integration/comm_rx/tb_comm_rx_rs422_cmd_path.sv` | 通过。验证 `RS422 -> rx_link -> host_ctrl_core -> comm_rx_cmd_agent`，确认 3 参数阈值组与 header-only pulse 组都能落到实现层参数。 |
| 发送半链路集成 | `sim/integration/comm_rx/tb_comm_rx_rs422_tm_path.sv` | 通过。验证 `comm_rx_tm_agent -> host_ctrl_core -> tx_link -> RS422 -> decoder`，确认 `COMM_RX runtime/cfg` 两帧都能从串口侧恢复出来。 |
| 旧 `sim/rs422` 命令入口 | `sim/rs422/tb_rs422_host_ctrl_cmd_path.sv` | 通过。已重写为现役接口 wrapper，内部调用当前通过的 `COMM_RX` 命令链集成用例。 |
| 旧 `sim/rs422` 遥测入口 | `sim/rs422/tb_rs422_host_ctrl_tm_path.sv` | 通过。已重写为现役接口 wrapper，内部调用当前通过的 `COMM_RX` 遥测链集成用例。 |

### 9.2 已确认但未继续复用的旧仿真

| 仿真文件 | 结论 |
| --- | --- |
| `sim/rs422` 原始旧实现 | 已确认与现役 `ctrl_status_host_ctrl_core` 接口不一致，旧扁平 `host_cmd_s_axis_* / host_stat_m_axis_*` 端口不能直接用于当前 RTL；现已由同名 wrapper 文件替代。 |
| `tb_host_ctrl_core_legacy_port_probe.sv`、`tb_comm_rx_cmd_agent_pulse_probe.sv` | 已完成定位任务后删除，不再保留。 |

补充证据：

- `sim/ctrl_status_block/frame_processing/tb_host_ctrl_core_legacy_port_probe.sv`
- `xelab` 明确报出旧扁平端口不存在

### 9.3 暂时跳过的仿真

| 仿真文件 | 状态 | 原因 |
| --- | --- | --- |
| 无 | 无 | 本轮原先跳过的完整回环已补测通过。 |

### 9.4 本轮执行后的最新结论

1. `COMM_RX ctrl_tm` 作为研究对象，本地命令链和本地遥测链已经分别通过仿真。
2. 从 `RS422` 到实现层的接收半链路已经通过仿真。
3. 从实现层到 `RS422` 的发送半链路已经通过仿真。
4. 因此，“一条指令下发、一条配置回读、一条 runtime 上传”三类核心流程已经在分层仿真中分别闭环。
5. 当前 `RS422` 与 `COMM_RX` 的主流程已全部通过分层仿真闭环。
