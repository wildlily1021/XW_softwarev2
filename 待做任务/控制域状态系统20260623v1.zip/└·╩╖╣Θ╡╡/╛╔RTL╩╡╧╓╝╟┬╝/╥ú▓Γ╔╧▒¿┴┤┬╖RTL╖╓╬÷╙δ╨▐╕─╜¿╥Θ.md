﻿# 遥测上报链路 RTL 分析与修改建议

## 1. 目的

本文档根据两个具体参数：

- `cfg.rate_sel`
- `runtime.signal_power`

反向检查当前 RTL 是否能完成完整的遥测上报流程，并记录本轮修改与复查结果。

---

## 2. 检查范围

本轮重点检查：

- `import/rtl_source/TOP/modules/comm_rx.sv`
- `import/rtl_source/TOP/modules/comm_rx_tm_agent.sv`
- `import/rtl_source/TOP/modules/comm_rx/comm_rx_pkg.sv`
- `import/rtl_source/HOST_CTRL_STATUS/module_tm/tm_frame_builder.sv`
- `import/rtl_source/HOST_CTRL_STATUS/protocol/top_host_ctrl.sv`
- `import/rtl_source/TOP/system/top.v`

---

## 3. 按示例参数反查原始 RTL

## 3.1 `cfg.rate_sel`

### 原始状态

原始 RTL 中，`cfg.rate_sel` 已经来自命令链落地后的真实配置结构：

- `tm_params_w.cfg = cmd_params_w.cfg`

因此：

- `cfg.rate_sel` 在遥测链中本来就是闭环的
- `comm_rx_tm_agent` 和 `tm_frame_builder` 只负责把它打包发出

### 结论

`cfg.rate_sel` 原始 RTL 已经可用，不需要额外结构性修改。

---

## 3.2 `runtime.signal_power`

### 原始状态

原始 RTL 中，`comm_rx_tm_agent` 的打包链是通的：

- `runtime_word()` 已经定义了 `signal_power` 在 `runtime` 组中的位置

但 `top_comm_rx` 中的 `runtime` 来源还是模块内部零值模板：

- `stat_from_impl_w`

这说明：

- runtime 组的打包方法是对的
- 但真实状态来源边界还不够正式

### 原始问题

问题不在：

- `comm_rx_tm_agent`
- `tm_frame_builder`

而在：

- `top_comm_rx`

它把 runtime 真实来源边界写成了模块内部占位逻辑，而不是显式输入接口。

---

## 4. 本轮 RTL 修改

## 4.1 修改 `top_comm_rx.sv`

本轮已改成：

- 新增显式输入端口
  - `input comm_rx_pkg::comm_rx_stat_t runtime_stat_i`
- 去掉模块内部 `stat_from_impl_w` 零值模板
- 固定使用：
  - `tm_params_w.stat = runtime_stat_i`

这样修改后：

1. runtime 真实状态边界正式显式化
2. `top_comm_rx` 不再保留内部重复零值占位逻辑
3. 后续真实业务状态接入时，只需要在上一级把状态整理成 `comm_rx_stat_t`

## 4.2 修改 `top.v`

本轮同步修改了 `top.v`：

- 增加顶层占位信号
  - `comm_rx_runtime_stat_w`
- 暂时保持：
  - `assign comm_rx_runtime_stat_w = '0;`
- 再把它接到：
  - `top_comm_rx.runtime_stat_i`

这样处理后：

- “零值占位”还保留
- 但位置已经从 `top_comm_rx` 内部移到更靠顶层的地方
- 边界更清晰，后续真实状态接入更直接

## 4.3 本轮未修改的文件

### `comm_rx_tm_agent.sv`

未做结构性修改。  
原因是它当前职责已经较纯：

- 收请求
- 锁快照
- 调 `runtime_word()/cfg_word()`
- 调 `tm_frame_builder`

### `tm_frame_builder.sv`

未修改。  
当前它负责：

- 输出 header
- 转发数据区

职责清楚，当前无需调整。

### `top_host_ctrl.sv`

未修改。  
当前它负责：

- 周期调度 `runtime -> cfg`
- 首拍前允许超时
- 首拍后必须整帧送完

这部分当前已经合理。

---

## 5. 修改后复查结论

## 5.1 `cfg.rate_sel`

修改后继续成立：

- 来源是命令链落地后的真实配置
- 在 `cfg_word()` 中按固定顺序打包
- 通过 `tm_frame_builder` 形成 payload

因此：

`cfg.rate_sel` 当前是闭环的真实配置回显参数

## 5.2 `runtime.signal_power`

修改后已变成：

- 来源是 `top_comm_rx.runtime_stat_i.signal_power`
- 在 `runtime_word()` 中按固定顺序打包
- 通过 `tm_frame_builder` 形成 payload

因此：

`runtime.signal_power` 当前的链路也已经正式闭环`

它是否为“真实业务值”，只取决于上一级是否把真实状态接入 `runtime_stat_i`。

---

## 6. 检查结果

本轮已完成两类检查。

### 6.1 主线 RTL 静态编译

检查结果：

- 主线文件 `xvlog` 编译通过
- `top` 可完成 `xelab` elaboration

说明本轮接口修改没有把系统级连接打坏。

### 6.2 `comm_rx_tm_agent` 专用仿真

本轮新增了：

- `sim/rs422/tb_comm_rx_tm_agent.sv`
- `sim/rs422/run_tb_comm_rx_tm_agent.tcl`

仿真覆盖：

1. `runtime` 组
   - 验证 `signal_power` 的上报字位置正确
2. `cfg` 组
   - 验证 `rate_sel` 的上报字位置正确
3. 快照锁存行为
   - 请求握手成功后再修改输入，当前帧仍应输出旧快照

仿真结果：

- `PASS: tb_comm_rx_tm_agent`

---

## 7. 本文结论

本轮按“具体参数示例 -> RTL 反查 -> RTL 修改 -> 再检查 -> 建仿真”的顺序完成后，当前遥测链得到的结论是：

1. `cfg.rate_sel`
   - 已经是完整可用的配置回显上报参数
2. `runtime.signal_power`
   - 当前链路已完整可用
   - 真实值来源边界已正式化为 `top_comm_rx.runtime_stat_i`
3. `comm_rx_tm_agent`
   - 当前功能正确
   - 已通过专用仿真验证

因此本轮 `comm_rx` 遥测链主线已经满足：

- 用具体参数解释上报流程
- 反向检查 RTL 是否能完成该流程
- 做最小必要的 RTL 完善
- 用专用仿真验证关键子模块功能

