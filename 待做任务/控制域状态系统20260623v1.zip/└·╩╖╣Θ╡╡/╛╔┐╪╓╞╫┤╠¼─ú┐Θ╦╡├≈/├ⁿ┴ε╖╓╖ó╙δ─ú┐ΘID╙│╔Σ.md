# 命令分发与模块ID映射

## 命令分发入口

所有主机遥控命令先进入 `top_ctrl_status_block`，在内部完成：

- 帧恢复
- 头字段解包
- `module_id` 识别
- 路由到对应一级模块的 `cmd_axis_t`

命令路径实际分为两级：

1. `ctrl_status_rs422_link_adapter` 负责把固定帧还原为 `host_cmd_axi4`
2. `ctrl_status_host_ctrl_core` 负责解析应用层头并按 `module_id` 路由到各一级模块

## 当前协议侧模块编号

当前控制与状态私有协议使用 `ctrl_status_block_pkg.sv` 内定义的 `4-bit module_id`：

| 协议侧 `module_id` | 常量名 | `master` 目标模块 | 顶层索引常量 |
| --- | --- | --- | --- |
| `4'h0` | `MODULE_ID_CLK_MGMT_C` | `top_clock_manager_block` | `MODULE_ID_CLOCK_MANAGER = 8'h01` |
| `4'h1` | `MODULE_ID_ADC_C` | `top_adc_rx_block` | `MODULE_ID_ADC_RX = 8'h02` |
| `4'h2` | `MODULE_ID_GT_C` | `top_gt_tx_block` | `MODULE_ID_GT_TX = 8'h03` |
| `4'h3` | `MODULE_ID_CXP_C` | `top_cxp_yewu_block` | `MODULE_ID_CXP_YEWU = 8'h04` |
| `4'h4` | `MODULE_ID_LASER_CTRL_C` | `top_laser_ctrl_block` | `MODULE_ID_LASER_CTRL = 8'h05` |
| `4'h5` | `MODULE_ID_BIZ_RX_C` | `top_yewu_rx_block` | `MODULE_ID_YEWU_RX = 8'h06` |
| `4'h6` | `MODULE_ID_BIZ_TX_C` | `top_yewu_tx_block` | `MODULE_ID_YEWU_TX = 8'h07` |
| `4'h7` | `MODULE_ID_COMM_TX_C` | `top_comm_tx_block` | `MODULE_ID_COMM_TX = 8'h08` |
| `4'h8` | `MODULE_ID_COMM_RX_C` | `top_comm_rx_block` | `MODULE_ID_COMM_RX = 8'h09` |
| `4'h9` | `MODULE_ID_CTRL_STATUS_C` | 保留，不接入遥控路由 | 无 |

## 映射原则

- 协议层内部继续使用 `4-bit module_id`
- 顶层公共框架继续使用 `common_pkg.sv` 里的 `8-bit module_id_t`
- `top.sv` 通过 `IDX_* = MODULE_ID_*` 的方式把顶层数组索引绑定到公共模块 ID
- `top_ctrl_status_block` 内部只做“协议侧目标模块 -> 顶层目标接口”的收口，不再保留旧 `top_host_ctrl` 风格目录

## 命令载荷解释边界

- 公共层只负责识别 `module_id`，不直接解释模块私有参数语义
- 进入某个一级模块后的 `cmd_axis_t`，再由该模块本地 `ctrl_status_cmd_param_splitter` / `ctrl_status_cmd_action_mapper` 和本地 `*_ctrl_pkg.sv` 完成组、参数、动作落地
- 当前现役应用层头中不再使用旧分支文档里的外部对象字段模型；现役口径见 [应用层协议头与消息语义说明.md](应用层协议头与消息语义说明.md)

## 当前实现状态

- 命令路由主线已经迁入 `master`
- `top_ctrl_status_block` 已经把 `clock_manager / adc_rx / gt_tx / cxp_yewu / laser_ctrl / yewu_rx / yewu_tx / comm_tx / comm_rx` 九个目标模块全部接入命令路由输出
- `MODULE_ID_CTRL_STATUS_C = 4'h9` 仅作为保留号存在，当前不参与本表路由、不下发控制
