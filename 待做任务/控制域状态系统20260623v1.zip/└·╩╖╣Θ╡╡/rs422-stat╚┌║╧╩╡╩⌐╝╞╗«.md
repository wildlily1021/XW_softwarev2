# rs422-stat 融合实施计划

## 阶段 1：接口与公共包

- 扩展 `top.sv`，增加 `tm_req_valid / tm_req_group_id / tm_req_ready` 数组
- 扩展所有一级 block 顶层接口，加入 `tm_req_*`
- 扩展 `ctrl_status_block_pkg.sv`，融合 `host_ctrl_pkg` 的公共协议定义

## 阶段 2：迁入 RS422 基础链路

- 迁入 `rs422_rx_phy / rs422_tx_phy`
- 迁入 `rs422_baud_gen`
- 迁入 `rs422_frame_rx / rs422_frame_tx`
- 迁入 `rs422_rx_link / rs422_tx_link / rs422_link_adapter`
- 按 `master` 风格重命名为 `ctrl_status_rs422_*`

## 阶段 3：迁入控制与状态核心

- 迁入 `cmd_param_splitter`
- 迁入 `cmd_action_mapper`
- 迁入 `tm_frame_builder`
- 迁入 `top_host_ctrl`
- 按 `master` 风格重命名并接到 `top_ctrl_status_block`

## 阶段 4：文档融合

- 更新 `控制与状态模块/README.md`
- 新增控制与状态专题说明文档
- 从 `主机控制与状态协议层/` 提取现役内容并重写到当前目录

## 阶段 5：验证

- `xvlog 2018.3` 验证：
  - `ctrl_status_block_pkg + ctrl_status_rs422_*`
  - `top_ctrl_status_block`
  - `top.sv + 所有一级 block`

## 当前执行方式

本轮直接在 `master` 工作区执行，不新开分支，不删除 `rs422-stat`。
